#!/usr/bin/env bash
# Monta repo-template/ (estado inicial VULNERAVEL: pipeline vermelho) e solucao/ (pipeline verde)
set -euo pipefail
cd "$(dirname "$0")/.."
for d in repo-template solucao; do
  rm -rf "$d"; mkdir -p "$d"/{app,deploy,infra,rules,tools}
  cp -r .github "$d"/
  cp rules/semgrep-sso.yml rules/semgrep-sso.py rules/gitleaks.toml "$d"/rules/
  cp lab/realm_lint.py tools/varredura_segredos.py tools/gate_local.sh tools/validar_regras.py "$d"/tools/
  sed '/# >>> VULNERAVEL-INICIO/,/# <<< VULNERAVEL-FIM/d' lab/jwt_validator.py > "$d"/app/jwt_validator.py   # repos do aluno levam SO o validador seguro
  cat > "$d/app/requirements.txt" <<'REQ'
Flask>=3.0,<4
PyJWT[crypto]>=2.8,<3
requests>=2.31,<3
gunicorn>=22.0
REQ
  printf '__pycache__/\n*.pyc\n.env\n*.env\n!*.env.exemplo\nvenv/\n' > "$d/.gitignore"
done
# ---- estado inicial (vulneravel)
cp lab/app_insegura.py repo-template/app/portal.py
cp lab/realms/realm_ruim.json repo-template/infra/realm-banco.json
cat > repo-template/deploy/Dockerfile <<'EOF2'
FROM python:latest
WORKDIR /app
COPY . .
RUN pip install flask pyjwt requests
ENV OIDC_CLIENT_SECRET=segredo-do-portal-gerente-lab
EXPOSE 5001
CMD ["python", "portal.py"]
EOF2
cat > repo-template/deploy/docker-compose.keycloak.yml <<'EOF2'
services:
  keycloak:
    image: quay.io/keycloak/keycloak:latest
    command: start-dev --import-realm
    environment:
      KC_BOOTSTRAP_ADMIN_USERNAME: admin
      KC_BOOTSTRAP_ADMIN_PASSWORD: admin123
    ports:
      - "8080:8080"
    volumes:
      - ../infra:/opt/keycloak/data/import:ro
EOF2
cat > repo-template/app/legado.env <<'EOF2'
# configuracao antiga copiada de outro projeto (NAO FACA ISSO)
OIDC_CLIENT_SECRET="Portal@2023!"
TOKEN_DE_TESTE="eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiJhZG1pbiIsInJvbGVzIjpbImdlcmVudGUiXX0.c2lnbmF0dXJhLWRlLWV4ZW1wbG8tZGlkYXRpY28"
EOF2
# ---- solucao (segura)
cp lab/app_segura.py solucao/app/portal.py
cp lab/realms/realm_bom.json solucao/infra/realm-banco.json
cat > solucao/deploy/Dockerfile <<'EOF2'
FROM python:3.12-slim
ENV PYTHONDONTWRITEBYTECODE=1 PYTHONUNBUFFERED=1
RUN useradd --create-home --uid 10001 appuser
WORKDIR /app
COPY app/requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY --chown=appuser:appuser app/ .
USER 10001
EXPOSE 5002
HEALTHCHECK --interval=30s --timeout=3s --retries=3 \
  CMD python -c "import urllib.request; urllib.request.urlopen('http://127.0.0.1:5002/', timeout=2)" || exit 1
CMD ["gunicorn", "-b", "0.0.0.0:5002", "portal:criar_app()"]
EOF2
cat > solucao/deploy/docker-compose.keycloak.yml <<'EOF2'
services:
  keycloak:
    image: quay.io/keycloak/keycloak:26.0
    command: start-dev --import-realm
    environment:
      KC_BOOTSTRAP_ADMIN_USERNAME: ${KC_ADMIN_USER:?defina KC_ADMIN_USER no ambiente}
      KC_BOOTSTRAP_ADMIN_PASSWORD: ${KC_ADMIN_PASSWORD:?defina KC_ADMIN_PASSWORD no ambiente}
    ports:
      - "127.0.0.1:8080:8080"
    volumes:
      - ../infra:/opt/keycloak/data/import:ro
EOF2
# ---- testes de seguranca do app (mesmo arquivo nos dois; no template DEVEM falhar)
for d in repo-template solucao; do
cat > "$d/app/test_seguranca.py" <<'EOF2'
"""Testes de seguranca da aplicacao - rodam no CI. No repo-template eles falham de proposito."""
import unittest

import portal


class TestSegurancaPortal(unittest.TestCase):
    def test_redirect_pos_login_so_caminho_interno(self):
        self.assertTrue(hasattr(portal, "_destino_seguro"),
                        "falta _destino_seguro(): a aplicacao aceita redirect para qualquer site")
        for mal in ["https://evil.exemplo", "//evil.exemplo", "/\\evil.exemplo", "javascript:alert(1)"]:
            self.assertEqual(portal._destino_seguro(mal), "/", mal)

    def test_cookie_de_sessao_endurecido(self):
        app = portal.criar_app()
        self.assertTrue(app.config["SESSION_COOKIE_HTTPONLY"], "cookie legivel por JavaScript")
        self.assertTrue(app.config["SESSION_COOKIE_SECURE"], "cookie trafega em HTTP puro")

    def test_chave_de_sessao_nao_e_fixa(self):
        a, b = portal.criar_app(), portal.criar_app()
        self.assertNotEqual(a.secret_key, "dev")
        self.assertGreaterEqual(len(str(a.secret_key)), 32)

    def test_operacao_critica_exige_mfa(self):
        c = portal.criar_app().test_client()
        with c.session_transaction() as s:                  # usuario com papel gerente, mas sem MFA (acr != "2")
            s["user"], s["roles"], s["acr"] = "ana.silva", ["gerente"], "1"
        self.assertEqual(c.get("/gerencia/limites").status_code, 401,
                         "operacao critica liberada sem MFA (falta o step-up por acr)")

    def test_api_rejeita_token_sem_assinatura(self):
        import base64, json
        b = lambda d: base64.urlsafe_b64encode(json.dumps(d).encode()).rstrip(b"=").decode()
        forjado = f"{b({'alg': 'none'})}.{b({'sub': 'admin', 'roles': ['gerente']})}."
        r = portal.criar_app().test_client().get("/api/me", headers={"Authorization": f"Bearer {forjado}"})
        self.assertEqual(r.status_code, 401, "API aceitou token forjado (alg=none)")


if __name__ == "__main__":
    unittest.main()
EOF2
done
echo montado
