#!/usr/bin/env bash
# Roda TODOS os testes do kit (sem internet; precisa de python3, flask, pyjwt, cryptography, requests)
# Debian: sudo apt install -y python3 python3-venv python3-flask python3-jwt python3-cryptography python3-requests python3-yaml
set -e
cd "$(dirname "$0")/lab"
python3 -m unittest test_totp test_jwt_attacks test_saml_xsw test_realm_lint test_e2e 2>&1 | grep -E "^(Ran|OK|FAILED|FAIL:|ERROR:)"
echo "--- exercicio do grupo: gabarito (ESPERADO: passar) ---"; EXERCICIO=jwt_validator:validar_seguro python3 -m unittest test_exercicio 2>&1 | tail -1
echo "--- exercicio do grupo: esqueleto (ESPERADO: falhar) ---"; python3 -m unittest test_exercicio 2>&1 | tail -1 || true
cd ..
python3 tools/validar_regras.py
./tools/montar_repos.sh >/dev/null
echo "--- repo-template (ESPERADO: falhar) ---"; (cd repo-template && python3 -m unittest discover -s app -p 'test_*.py' 2>&1 | tail -1) || true
echo "--- solucao (ESPERADO: passar) ---";       (cd solucao && python3 -m unittest discover -s app -p 'test_*.py' 2>&1 | tail -1)
