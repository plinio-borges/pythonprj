# Kit de laboratorio - SSO e Autenticacao Federada (Aula 09)

## Estrutura
- `lab/`            codigo didatico + testes (totp, jwt_validator, saml_xsw_demo, mini_idp, app_insegura, app_segura, realm_lint)
- `rules/`          regras Semgrep (13), gitleaks.toml (6 regras), fixture de teste das regras
- `.github/workflows/`  7 workflows GitHub Actions (Semgrep, Bandit, Gitleaks, Trivy, realm-lint, testes, gate)
- `repo-template/`  repositorio INICIAL de cada grupo (vulneravel -> pipeline vermelho)
- `solucao/`        repositorio corrigido (pipeline verde) - gabarito do instrutor
- `tools/`          montar_repos.sh, validar_regras.py
- `run_all.sh`      executa tudo e mostra o resultado esperado

## Na VM Debian (sem internet)
    sudo apt install -y python3 python3-venv python3-flask python3-jwt python3-cryptography python3-requests python3-yaml git
    ./run_all.sh
    # IdP de laboratorio:   cd lab && python3 mini_idp.py          (porta 9000)
    # App insegura:         python3 app_insegura.py                  (porta 5001)
    # App segura:           OIDC_CLIENT_SECRET=segredo-do-portal-gerente-lab python3 app_segura.py   (porta 5002)

## O que foi e o que NAO foi testado no preparo
TESTADO (63 testes): TOTP (vetores RFC 4226/6238), 16 ataques a JWT, SAML XSW (modelo didatico), fluxo OIDC
ponta a ponta (code+PKCE+MFA), linter de realm, regex do gitleaks (com 're' do Python), estrutura dos workflows e regras.
NAO TESTADO (sem acesso a PyPI/npm/GitHub/Docker no preparo): execucao real de Semgrep, Bandit, Gitleaks, Trivy,
Keycloak em Docker, e os workflows no GitHub. Rode tudo uma vez antes da aula (ver Anexo H do material).
