#!/usr/bin/env python3
"""
varredura_segredos.py - Varredura OFFLINE de segredos usando as MESMAS regex de rules/gitleaks.toml.
E um 'plano B' didatico para quando o binario do Gitleaks nao esta instalado na VM. NAO substitui o Gitleaks:
  - nao le o historico git (so a arvore de trabalho)  -> use 'gitleaks detect' para o historico;
  - as regex sao avaliadas pelo motor 're' do Python (o Gitleaks usa Go/RE2): pequenas diferencas sao possiveis.
Uso:  python3 tools/varredura_segredos.py [pasta]      codigo de saida 1 se achar algo.
"""
import pathlib
import re
import sys
import tomllib

RAIZ = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
CFG = RAIZ / "rules" / "gitleaks.toml"
if not CFG.exists():
    print(f"nao encontrei {CFG}", file=sys.stderr); sys.exit(2)
cfg = tomllib.loads(CFG.read_text())
regras = [(r["id"], re.compile(r["regex"]), r.get("secretGroup", 0)) for r in cfg["rules"]]
ignorar = [re.compile(x) for x in cfg.get("allowlist", {}).get("paths", [])]
PULAR_DIR = {".git", "__pycache__", "venv", "node_modules"}
achados = []
for f in sorted(RAIZ.rglob("*")):
    if not f.is_file() or PULAR_DIR & set(f.relative_to(RAIZ).parts):
        continue
    rel = str(f.relative_to(RAIZ))
    if any(rx.search(rel) for rx in ignorar):
        continue
    try:
        linhas = f.read_text(errors="ignore").splitlines()
    except Exception:
        continue
    for n, linha in enumerate(linhas, 1):
        for rid, rx, grp in regras:
            m = rx.search(linha)
            if m:
                segredo = m.group(grp) if grp else m.group(0)
                mascarado = segredo[:2] + "*" * max(len(segredo) - 2, 3)      # equivalente a --redact
                achados.append((rel, n, rid, mascarado))
for rel, n, rid, seg in achados:
    print(f"[{rid}] {rel}:{n}  valor={seg}")
print(f"\n{len(achados)} achado(s) (varredura offline da arvore; nao cobre o historico git)")
sys.exit(1 if achados else 0)
