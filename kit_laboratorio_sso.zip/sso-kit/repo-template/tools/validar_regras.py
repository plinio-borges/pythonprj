#!/usr/bin/env python3
"""Valida (sem as ferramentas externas) a sintaxe/estrutura das regras Semgrep, gitleaks.toml e workflows,
e testa os regex do gitleaks contra exemplos positivos/negativos. Uso: python3 tools/validar_regras.py"""
import glob
import pathlib
import re
import sys
import tomllib

import yaml

RAIZ = pathlib.Path(__file__).resolve().parent.parent
erros = []

# --- gitleaks
t = tomllib.load(open(RAIZ / "rules/gitleaks.toml", "rb"))
rules = {r["id"]: r for r in t["rules"]}
CASOS = {
    "oidc-client-secret": (['CLIENT_SECRET = "segredo-do-portal-gerente-lab"', "client_secret: 'Abc12345!x'",
                            '"clientSecret": "SuperSecreto123"'],
                           ['CLIENT_SECRET = os.environ["X"]', 'client_secret = ""', 'client_secret = "curto"']),
    "keycloak-realm-secret": (['"secret": "Portal@2023!"'], ['"secret": "**********"', '"secret": ""']),
    "idp-admin-password": (["KC_BOOTSTRAP_ADMIN_PASSWORD: admin123", "KC_BOOTSTRAP_ADMIN_PASSWORD=Troque#Me1"],
                           ["KC_BOOTSTRAP_ADMIN_PASSWORD: ${KC_ADMIN_PW}"]),
    "jwt-literal": (['token = "eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJhbmEifQ.abcdefghijklmnop"'],
                    ["eyJhbGciOiJub25lIn0", "a.b.c"]),
    "flask-secret-key-literal": (['app.secret_key = "dev"', "SECRET_KEY = 'abc123'",
                                  'app.config["SECRET_KEY"] = "x1y2"'], ['app.secret_key = os.environ["K"]']),
    "totp-seed-base32": (['otp_secret = "JBSWY3DPEHPK3PXPJBSWY3DP"', "totp_seed: JBSWY3DPEHPK3PXP",
                          "otpauth://totp/x?secret=JBSWY3DPEHPK3PXP&issuer=y"],
                         ['otp_secret = os.environ["O"]', "secret=curto"]),
}
for rid, (pos, neg) in CASOS.items():
    rx = re.compile(rules[rid]["regex"])
    erros += [f"gitleaks {rid}: deveria casar: {s}" for s in pos if not rx.search(s)]
    erros += [f"gitleaks {rid}: NAO deveria casar: {s}" for s in neg if rx.search(s)]
total = sum(len(p) + len(n) for p, n in CASOS.values())
print(f"gitleaks.toml: {len(rules)} regras customizadas, {total} casos de teste (regex avaliado com Python 're')")

# --- semgrep
d = yaml.safe_load(open(RAIZ / "rules/semgrep-sso.yml"))
ids = []
for r in d["rules"]:
    ids.append(r["id"])
    falta = {"id", "languages", "severity", "message"} - set(r)
    if falta or not any(k in r for k in ("pattern", "patterns", "pattern-either", "pattern-regex")):
        erros.append(f"semgrep {r['id']}: campos ausentes {falta}")
fix = (RAIZ / "rules/semgrep-sso.py").read_text()
usados = set(re.findall(r"# (?:ruleid|ok): ([\w-]+)", fix))
erros += [f"fixture referencia regra inexistente: {u}" for u in usados - set(ids)]
sem_teste = sorted(set(ids) - usados)
print(f"semgrep-sso.yml: {len(ids)} regras; sem caso na fixture: {sem_teste or 'nenhuma'}")

# --- workflows
for wf in sorted(glob.glob(str(RAIZ / ".github/workflows/*.yml"))):
    y = yaml.safe_load(open(wf))
    nome = pathlib.Path(wf).name
    gatilhos = y.get(True, y.get("on"))             # PyYAML le 'on' como True
    if not gatilhos or "jobs" not in y:
        erros.append(f"{nome}: sem 'on' ou 'jobs'")
        continue
    for jn, j in y["jobs"].items():
        if "uses" in j:
            if not j["uses"].startswith("./"):
                erros.append(f"{nome}/{jn}: workflow reutilizavel externo sem revisao")
            continue
        if "runs-on" not in j or not j.get("steps"):
            erros.append(f"{nome}/{jn}: sem runs-on/steps")
        for i, s in enumerate(j.get("steps", [])):
            if not ("uses" in s or "run" in s):
                erros.append(f"{nome}/{jn} passo {i}: sem uses/run")
            if "uses" in s and not re.search(r"@(v\d+|[0-9a-f]{40})", s["uses"]) and not s["uses"].startswith("./"):
                erros.append(f"{nome}/{jn} passo {i}: acao sem versao fixada: {s['uses']}")
    g = list(gatilhos) if isinstance(gatilhos, dict) else gatilhos
    print(f"{nome}: ok ({len(y['jobs'])} job(s); gatilhos: {g})")

if erros:
    print("\nERROS:")
    for e in erros:
        print(" -", e)
    sys.exit(1)
print("\nTudo certo (validacao ESTRUTURAL - as ferramentas em si rodam no CI).")
