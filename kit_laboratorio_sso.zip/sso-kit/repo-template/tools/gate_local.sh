#!/usr/bin/env bash
# gate_local.sh - roda localmente o MESMO conjunto de verificacoes do pipeline, usando o que estiver instalado.
# Uso (dentro do repositorio do grupo):  ./tools/gate_local.sh
cd "$(dirname "$0")/.."
export PYTHONDONTWRITEBYTECODE=1                 # evita .pyc obsoleto (editar na mesma hora/tamanho enganava o teste)
find . -name __pycache__ -prune -exec rm -rf {} + 2>/dev/null
falhas=0
roda() {  # roda NOME comando...
  local nome="$1"; shift
  if "$@" >/tmp/gate_$$.log 2>&1; then echo "  [ OK ] $nome"; else echo "  [FALHA] $nome"; sed 's/^/          /' /tmp/gate_$$.log | tail -${LINHAS:-6}; falhas=$((falhas+1)); fi
}
pula() { echo "  [PULOU] $1 (ferramenta nao instalada - rode no CI)"; }
echo "== Gate local de seguranca =="
roda "testes de seguranca da app"      python3 -m unittest discover -s app -p "test_*.py"
roda "realm-lint (config do IdP)"      python3 tools/realm_lint.py infra/realm-banco.json --fail-on media
roda "segredos (varredura offline)"    python3 tools/varredura_segredos.py .
roda "regras (sintaxe/regex)"          python3 tools/validar_regras.py
command -v semgrep  >/dev/null && roda "semgrep"  semgrep scan --config rules/semgrep-sso.yml --metrics=off --error app/ deploy/ infra/ || pula semgrep
command -v bandit   >/dev/null && roda "bandit"   bandit -r app -x app/test_seguranca.py -ll -q               || pula bandit
command -v gitleaks >/dev/null && roda "gitleaks" gitleaks detect --source . --config rules/gitleaks.toml --redact --no-banner || pula gitleaks
command -v trivy    >/dev/null && roda "trivy"    trivy config --severity HIGH,CRITICAL --exit-code 1 deploy/    || pula trivy
rm -f /tmp/gate_$$.log
if [ "$falhas" -eq 0 ]; then echo "== GATE: APROVADO =="; else echo "== GATE: REPROVADO ($falhas verificacao(oes)) =="; fi
exit $falhas
