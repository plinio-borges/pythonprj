# Fixture de teste das regras (semgrep --test rules/). 'ruleid' = DEVE achar; 'ok' = NAO deve achar.
import logging
import jwt
import requests
from flask import Flask, redirect, request, session
from lxml import etree

app = Flask(__name__)
logger = logging.getLogger(__name__)

# ruleid: sso-jwt-verify-signature-disabled
c1 = jwt.decode(tok, options={"verify_signature": False})
# ok: sso-jwt-verify-signature-disabled
c2 = jwt.decode(tok, key, algorithms=["RS256"], audience="portal", issuer="https://idp")

# ruleid: sso-jwt-alg-none-permitido
c3 = jwt.decode(tok, key, algorithms=["RS256", "none"], audience="x")

# ruleid: sso-jwt-decode-sem-audience
c4 = jwt.decode(tok, key, algorithms=["RS256"])

# ruleid: sso-requests-verify-false
requests.get("https://idp/jwks", verify=False, timeout=3)
# ruleid: sso-requests-sem-timeout
requests.post("https://idp/token", data={})
# ok: sso-requests-sem-timeout
requests.post("https://idp/token", data={}, timeout=5)

# ruleid: sso-client-secret-hardcoded
CLIENT_SECRET = "abc123"
# ok: sso-client-secret-hardcoded
CLIENT_SECRET = ""

# ruleid: sso-flask-secret-key-literal
app.secret_key = "dev"

# ruleid: sso-flask-cookie-sessao-inseguro
app.config["SESSION_COOKIE_SECURE"] = False

# ruleid: sso-flask-debug-true
app.run(debug=True)
# ok: sso-flask-debug-true
app.run(debug=False)

# ruleid: sso-open-redirect-parametro
redirect(request.args.get("next"))
# ruleid: sso-open-redirect-parametro
redirect(session.pop("next", "/"))

# ruleid: sso-token-em-log
logger.warning("login ok %s", id_token)
# ok: sso-token-em-log
logger.warning("id_token rejeitado: %s", motivo)

# ruleid: sso-xml-parser-entidades-externas
p = etree.XMLParser(resolve_entities=True)


# ruleid: sso-oauth-callback-sem-state
def callback_ruim():
    code = request.args.get("code")
    return code


# ok: sso-oauth-callback-sem-state
def callback_bom():
    if request.args.get("state") != session["state"]:
        return "erro", 400
    code = request.args.get("code")
    return code
