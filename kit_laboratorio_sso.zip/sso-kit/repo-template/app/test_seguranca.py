"""Testes de seguranca da aplicacao - rodam no CI. No repo-template eles falham de proposito."""
import unittest

import portal


class TestSegurancaPortal(unittest.TestCase):
    def test_redirect_pos_login_so_caminho_interno(self):
        self.assertTrue(hasattr(portal, "_destino_seguro"),
                        "falta _destino_seguro(): a aplicacao aceita redirect para qualquer site")
        for mal in ["https://evil.exemplo", "//evil.exemplo", "/\\evil.exemplo", "javascript:alert(1)"]:
            self.assertEqual(portal._destino_seguro(mal), "/", mal)

    def test_cookie_de_sessao_endurecido(self):
        app = portal.criar_app()
        self.assertTrue(app.config["SESSION_COOKIE_HTTPONLY"], "cookie legivel por JavaScript")
        self.assertTrue(app.config["SESSION_COOKIE_SECURE"], "cookie trafega em HTTP puro")

    def test_chave_de_sessao_nao_e_fixa(self):
        a, b = portal.criar_app(), portal.criar_app()
        self.assertNotEqual(a.secret_key, "dev")
        self.assertGreaterEqual(len(str(a.secret_key)), 32)

    def test_operacao_critica_exige_mfa(self):
        c = portal.criar_app().test_client()
        with c.session_transaction() as s:                  # usuario com papel gerente, mas sem MFA (acr != "2")
            s["user"], s["roles"], s["acr"] = "ana.silva", ["gerente"], "1"
        self.assertEqual(c.get("/gerencia/limites").status_code, 401,
                         "operacao critica liberada sem MFA (falta o step-up por acr)")

    def test_api_rejeita_token_sem_assinatura(self):
        import base64, json
        b = lambda d: base64.urlsafe_b64encode(json.dumps(d).encode()).rstrip(b"=").decode()
        forjado = f"{b({'alg': 'none'})}.{b({'sub': 'admin', 'roles': ['gerente']})}."
        r = portal.criar_app().test_client().get("/api/me", headers={"Authorization": f"Bearer {forjado}"})
        self.assertEqual(r.status_code, 401, "API aceitou token forjado (alg=none)")


if __name__ == "__main__":
    unittest.main()
